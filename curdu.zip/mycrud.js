$(function(){
$("#showMovies").click(function() {
  $.ajax({
    method:"GET",
    url: "http://localhost:3000/movielist",
    dataType: "json",
    success: function (response) {
      $.each(response, function(i, movie) {
	    const rowText = "<tr>" +
          "<td>" + movie.idmovielist + "</td>" +
          "<td>" + movie.name + "</td>" +
          "<td>" + movie.thumbnail_path + "</td>" +
          "<td>" + movie.description + "</td>" +
          "<td>" + movie.year_released + "</td>" +
          "<td>" + movie.language_released + "</td>" +
          "<td>" + "<button button id = \"deleteMovie\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#exampleModal\">Delete</button>" + "</td>" +
          "<td>" + "<button button id = \"editMovie\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#exampleModal\">Edit</button>" + "</td>";
        $("#movies").append(rowText);
      });
      loadButton();
    }
  });
});
function getOneMovie(id){
          $.ajax({
              url: 'http://localhost:3000/movielist' + id,
              method: 'GET',
              dataType: 'json',
              success: function(data) {
                  $($("#updateForm")[0].movieId).val(data._id);
                  $($("#updateForm")[0].intNum).val(data.intNum);
                  $($("#updateForm")[0].name).val(data.name);
                  $($("#updateForm")[0].thumnail_path).val(data.thumnail_path);
                  $($("#updateForm")[0].description).val(data.description);
                  $($("#updateForm")[0].year_released).val(data.year_released);
                  $($("#updateForm")[0].language_released).val(data.language_released);
                  $("#updateForm").show();
              }
          });
      }
$("#movieAdded").click(function(a){
  let mydata = {
    idmovielist: $($("#newForm")[0].intNum).val(),
    name:$($("#newForm")[0].name).val(),
    thumnail_path:$($("#newForm")[0].thumnail_path).val(),
    description:$($("#newForm")[0].description).val(),
    year_released:$($("#newForm")[0].year_released).val(),
    language_released:$($("#newForm")[0].language_released).val(),
  }
  displayMovie(mydata);
       $("#newForm").trigger("reset");
       $("#newForm").toggle();
       a.preventDefault();
});
function displayMovie(data) {
  $.ajax({
    method:"POST",
    url: "http://localhost:3000/movielist/addMovie",
    dataType: "json",
    data: data,
    success: function (data) {
          console.log(data);
    }
});
}
function loadButton() {
        $(".editMovie").click(function(a){
          getOneMovie($($(this)[0]).data("movieId"));
            a.preventDefault();
        });

        $(".deleteMovie").click(function(a){
            deleteMovie($($(this)[0]).data("movieId"));
            a.preventDefault();
        });
    }

    function putMovie(id, data){
        $.ajax({
            url: 'http://localhost:3000/movielist/update/' + id,
            method: 'PUT',
            dataType: 'json',
            data: data,
            success: function(data) {
                console.log(data);
                getOneMovie();
            }
        });
    }

    $("#updateMovie").on("click", function(a) {
       let data = {
         idmovielist: $($("#updateForm")[0].intNum).val(),
         name:$($("#updateForm")[0].name).val(),
         thumnail_path:$($("#updataForm")[0].thumnail_path).val(),
         description:$($("#updateForm")[0].description).val(),
         year_released:$($("#updateForm")[0].year_released).val(),
         language_released:$($("#updateForm")[0].language_released).val(),
       }

       putMovie($($("#updateForm")[0].movieId).val(), data);
           $("#updateForm").trigger("reset");
           $("#updateForm").toggle();
           a.preventDefault();

    });


    function deleteMovie(id){
        $.ajax({
            url: "http://localhost:3000/movielist/" + id,
            method: 'DELETE',
            dataType: 'json',
            success: function(data) {
                console.log(data);
            }
        });
    }

});

/*
$.ajax({
   method:"DELETE",
   url: "http://localhost:3000/movielist/16",
   dataType: "json",
   success: function (data) {
     $.each(data, function(i, movie) {
    const rowText = "<tr>" +
         "<td>" + movie.idmovielist + "</td>" +
         "<td>" + movie.name + "</td>" +
         "<td>" + movie.thumbnail_path + "</td>" +
         "<td>" + movie.description + "</td>" +
         "<td>" + movie.year_released + "</td>" +
         "<td>" + movie.language_released + "</td>" +
         "<td>" + "<button button id = \"deleteMovie\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#exampleModal\">Delete</button>" + "</td>" +
         "<td>" + "<button button id = \"editMovie\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#exampleModal\">Edit</button>" + "</td>";
       $("#movies").append(rowText);
     });
   }
});
*/
/*
$.ajax({
   method:"PUT",
   url: "http://localhost:3000/movielist/6",
   dataType: "json",
   data: {
       idmovielist: 6,
       name: 'Lion King',
       thumanail_path: '"https://lumiere-a.akamaihd.net/v1/images/',
       description: 'cartoon',
       year_realeased: '2000',
       language_released: 'english'
   },
   success: function (data) {
     $.each(data, function(i, movie) {
    const rowText = "<tr>" +
         "<td>" + movie.idmovielist + "</td>" +
         "<td>" + movie.name + "</td>" +
         "<td>" + movie.thumbnail_path + "</td>" +
         "<td>" + movie.description + "</td>" +
         "<td>" + movie.year_released + "</td>" +
         "<td>" + movie.language_released + "</td>" +
         "<td>" + "<button button id = \"deleteMovie\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#exampleModal\">Delete</button>" + "</td>" +
         "<td>" + "<button button id = \"editMovie\" type=\"button\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#exampleModal\">Edit</button>" + "</td>";
       $("#movies").append(rowText);
     });
   }
});
*/
